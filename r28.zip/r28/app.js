var express = require('express');
var app = express();
var UsuarioController = require('./controller/UsuarioController');
var AgendaController = require('./controller/AgendaController');
var ClienteController = require('./controller/ClienteController');
var AutentificacionController = require('./controller/AutentificacionController.js');
var Vistas = require('./controller/VistasController.js');
app.use('/api/usuario', UsuarioController);
app.use('/api/agenda', AgendaController);
//app.use('/api/evento', AgendaController); //para los detalles de un solo evento
app.use('/api/cliente', ClienteController)
app.use('/auth', AutentificacionController);
app.use('/', Vistas);

module.exports = app;
