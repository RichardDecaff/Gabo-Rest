var pool = require("../config/connectionPool.js");
//necesitas tener una copia local, no voy a poner las credenciales en un repo público

class Agenda {

  constructor(agenda_id, tipo, titulo, horaInicio, duracion, diaCompleto, rp, vendedor, supercede, creadoPor, creadoEn, cliente_id, visibilidad){
    this.agenda_id = agenda_id;
    this.tipo = tipo;
    this.titulo = titulo;
    this.horaInicio = horaInicio;
    this.duracion = duracion;
    this.diaCompleto =diaCompleto;
    this.rp = rp;
    this.vendedor = vendedor;
    this.supercede = supercede;
    this.creadoPor = creadoPor;
    this.creadoEn = creadoEn;
    this.cliente_id = cliente_id;
    this.visibilidad = visibilidad;
  }

  static getAgendaPorId(id, callback){
      var agenda_query = "select * from tabla_agenda where agenda_id = "+pool.escape(parseInt(id));
      pool.query(agenda_query, function(err, result, fields) {
        if (err) throw(err);
        callback(null, result[0])
      });
  }

  static getAgendas(callback){
    var agenda_query = "select * from tabla_agenda";
    //limitar a 5 dias anteriores
    pool.query(agenda_query, function(err, result, fields) {
      if (err) throw(err);
      callback(null, result)
    });
}

  static getAgendasPorUsuarioId(id, callback){
    var agenda_query = "select * from tabla_agenda where creadoPor = "+pool.escape(parseInt(id));
    pool.query(agenda_query, function(err, result, fields) {
      if (err) throw(err);
      callback(null, result)
    });
}

static getAgendasPorClienteId(id, callback){
    var agenda_query = "select * from tabla_agenda where cliente_id = "+pool.escape(parseInt(id));
    pool.query(agenda_query, function(err, result, fields) {
      if (err) throw(err);
      callback(null, result)
    });
}

  static crearAgenda(agenda, callback){
      pool.query('INSERT INTO tabla_agenda SET ?', agenda, function(error, result) {
        if (error) throw(error);
        callback(null,{"agenda_id" : result.insertId});
      });
  }

  static patchAgenda(id, name, value, callback){
    //console.log('name: ' + name + ', value: ' + value);
    var theQuery = "UPDATE tabla_agenda SET " + name + " = " + pool.escape(value) + " WHERE agenda_id = " + id;
    //TODO escape 'name' por seguridad, pero asegurarse de que no se pase con comillas o rompe al query
    //console.log(theQuery);
    pool.query(theQuery, function(err, result) {
      if (err) throw(err);
      callback(null, result)
    });
  }
}
module.exports = Agenda;
