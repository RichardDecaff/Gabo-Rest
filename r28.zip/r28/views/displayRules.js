var displayRulesLoaded = true;

var labelsCliente = {
  registro: '<span class=\"uk-label\">Registro</span>',
  demo_realizada: '<span class=\"uk-label uk-label-warning\">Cita hecha</span>',
  venta: '<span class=\"uk-label uk-label-success\">Venta</span>',
  no_venta: '<span class=\"uk-label uk-label-danger\">No venta</span>',
  postventa: '<span class=\"uk-label uk-label-warning\">Postventa</span>',
  cancelada: '<span class=\"uk-label uk-label-danger\">Cancelada</span>',
  pre_archivado: '<span class=\"uk-label uk-label-danger\">Archivado</span>'
};

var botonesCliente = {
  registro: '<span uk-icon=\"icon: future\"></span>',
  demo_realizada: '<span uk-icon=\"icon: check\"></span> <span uk-icon=\"icon: ban\"></span>',
  venta: '<span uk-icon=\"icon: calendar\"></span>',
  no_venta: '',
  postventa: '',
  cancelada: '',
  pre_archivado: '',
  default: ''
};

var labelsAgenda = {
  demo: '<span class=\"uk-label uk-align-right\">Demo</span>',
  pago: '<span class=\"uk-label uk-label-success uk-align-right\">Pago</span>',
  entrega: '<span class=\"uk-label uk-label-success uk-align-right\">Entrega</span>',
  postventa: '<span class=\"uk-label uk-label-warning uk-align-right\">Postventa</span>'
};

function botonesAgenda() {
  return ('<span uk-icon=\"icon: user\"></span> <span uk-icon=\"icon: calendar\"></span> <span uk-icon=\"icon: future\"></span>');
  //bind events somewhere here
}
