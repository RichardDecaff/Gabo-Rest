var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());
var Cliente = require('../model/Cliente.js');
var VerificarToken = require('./VerificarToken.js');


router.get('/:id', function (req, res) {
    Cliente.getClientePorId(req.params.id, function (err, cliente) {
        if (err) return res.status(500).send("Problema con la coneccion.");
        if (!cliente) return res.status(404).send("El cliente no fue encontrado.");
        res.status(200).send(cliente);
    });
});

router.get('/nombre/:id', function (req, res) {
    Cliente.getNombreCliente(req.params.id, function (err, cliente) {
        if (err) return res.status(500).send("Problema con la coneccion.");
        if (!cliente) return res.status(404).send("El cliente no fue encontrado.");
        res.status(200).send(cliente);
    });
});

router.get('/', function (req, res) {
    Cliente.getClientes(function (err, cliente) {
        if (err) return res.status(500).send("Problema con la coneccion.");
        if (!cliente) return res.status(404).send("No se encontraron clientes.");
        res.status(200).send(cliente);
    });
});

router.get('/usuario/:id', function (req, res) {
    Cliente.getClientesPorUsuarioId(req.params.id, function (err, cliente) {
        if (err) return res.status(500).send("Problema con la coneccion.");
        if (!cliente) return res.status(404).send("No se encontraron clientes para el usuario.");
        res.status(200).send(cliente);
    });
});

router.post('/', VerificarToken, function (req, res) {
    var clien = new Cliente(req.body.givenName, req.body.familyName, req.body.telFijo, req.body.telMovil,
      req.body.email, req.body.dirCalle, req.body.dirNumExt, req.body.dirNumInt, req.body.dirCol, req.body.dirCP,
      req.body.dirRef, 'registro', req.body.notas, req.usuario_id, new Date());
    Cliente.crearCliente(clien, function (err, cliente) {
        if (err) return res.status(500).send("Problema con la coneccion.");
        if (!cliente) return res.status(404).send("El cliente no fue creado.");
        res.status(200).send(cliente);
    });
});

router.patch('/:id/:f', function(req, res) {
  //por ahora solo se patchea un parámetro a la vez, sorry
  //TODO verificar congruencie entre :f y body[f]
  Cliente.patchCliente(req.params.id, req.params.f, req.body[req.params.f],function(e, cliente){ //(id, name, value, callback)
    if (e) return res.status(500).send("Algo salió mal ");
    res.status(200).send(cliente);
  })
});

module.exports = router;

//https://www.npmjs.com/package/sql-update-generator
//https://csnw.github.io/sql-bricks/
