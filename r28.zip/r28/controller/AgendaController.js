var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());
var Agenda = require('../model/Agenda.js');
var VerificarToken = require('./VerificarToken.js');

//GET un único evento por su ID
router.get('/:id', function (req, res) {
    Agenda.getAgendaPorId(req.params.id, function (err, agenda) {
        if (err) return res.status(500).send("Problema con la conexion.");
        if (!agenda) return res.status(404).send("El evento no fue encontrado.");
        res.status(200).send(agenda);
    });
});

//GET todos los eventos de todos los usuarios (agenda global)
router.get('/', function (req, res) {
    Agenda.getAgendas(function (err, agenda) {
        if (err) return res.status(500).send("Problema con la conexion.");
        if (!agenda) return res.status(404).send("No se encontraron agendas.");
        res.status(200).send(agenda);
    });
});

//GET todos los eventos que pertenecen a un usuario
router.get('/usuario/:id', function (req, res) {
    Agenda.getAgendasPorUsuarioId(req.params.id, function (err, agenda) {
        if (err) return res.status(500).send("Problema con la conexion.");
        if (!agenda) return res.status(404).send("No se encontraron agendas para el usuario.");
        res.status(200).send(agenda);
    });
});

//GET todos los eventos creados para un cliente
router.get('/cliente/:id', function (req, res) {
    Agenda.getAgendasPorClienteId(req.params.id, function (err, agenda) {
        if (err) return res.status(500).send("Problema con la conexion.");
        if (!agenda) return res.status(404).send("No se encontraron eventos para el cliente.");
        res.status(200).send(agenda);
    });
});

//Crear un evento
router.post('/', VerificarToken, function (req, res) {
    var evento = new Agenda(
      //agenda_id, tipo, titulo, horaInicio, duracion, diaCompleto, rp, vendedor, supercede, creadoPor, creadoEn, cliente_id, visibilidad
      null,
      req.body.tipo,
      req.body.titulo,
      new Date(req.body.horaInicio),
      req.body.duracion || 3600,
      req.body.diaCompleto || false,
      req.body.rp || '',
      req.body.vendedor || '',
      '',
      req.usuario_id,
      new Date(),
      req.body.cliente_id,
      req.body.visibilidad || 1
      );
    //console.log(evento);
    Agenda.crearAgenda(evento, function (err, agenda) {
        if (err) return res.status(500).send("Problema con la coneccion.");
        if (!agenda) return res.status(404).send("La agenda no fue creada.");
        res.status(200).send(agenda);
    });
});
//TODO no dejar encimar citas
//TODO validar que la fecha no sea en el pasado

router.patch('/:id/:f', function(req, res) {
  //por ahora solo se patchea un parámetro a la vez, sorry
  Agenda.patchAgenda(req.params.id, req.params.f, req.body[req.params.f],function(e, agenda){ //(id, name, value, callback)
    if (e) return res.status(500).send("Algo salió mal ");
    res.status(200).send(agenda);
  })
});

module.exports = router;
