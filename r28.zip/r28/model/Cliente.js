var pool = require("../config/connectionPool.js");

class Cliente {

  constructor(givenName, familyName, telFijo, telMovil, email, dirCalle, dirNumExt, dirNumInt, dirCol, dirCP, dirRef, status, notas, creadoPor, creadoEn){
    this.givenName = givenName;
    this.familyName = familyName;
    this.telFijo = telFijo;
    this.telMovil = telMovil;
    this.email = email;
    this.dirCalle = dirCalle;
    this.dirNumExt = dirNumExt;
    this.dirNumInt = dirNumInt;
    this.dirCol = dirCol;
    this.dirCP = dirCP;
    this.dirRef = dirRef;
    this.status = status;
    this.notas = notas;
    this.creadoPor = creadoPor;
    this.creadoEn = creadoEn;
    //creadoEn: SQL usa la hora del servidor al crear el registro
  }

  static getClientePorId(id, callback){
      var cliente_query = "select * from tabla_cliente where cliente_id = "+pool.escape(parseInt(id));
      pool.query(cliente_query, function(err, result, fields) {
        if (err) throw(err);
        callback(null, result[0])
      });
  }

  static getNombreCliente(id){
      var cliente_query = "select givenName, familyName from tabla_cliente where cliente_id = "+pool.escape(parseInt(id));
      pool.query(cliente_query, function(err, result, fields) {
        if (err) throw(err);
        callback(null, result[0])
      });
  }

  static getClientes(callback){
    var cliente_query = "select * from tabla_cliente";
    pool.query(cliente_query, function(err, result, fields) {
      if (err) throw(err);
      callback(null, result)
    });
}

  static getClientesPorUsuarioId(id, callback){
    var cliente_query = "select * from tabla_cliente where creadoPor = "+pool.escape(parseInt(id));
    pool.query(cliente_query, function(err, result, fields) {
      if (err) throw(err);
      callback(null, result)
    });
}

  static crearCliente(cliente, callback){
    //console.log(cliente); //sanity check
      pool.query('INSERT INTO tabla_cliente SET ?', cliente, function(error, result) {
        if (error) throw(error);
        callback(null,{"cliente_id" : result.insertId});
      });
  }

  static patchCliente(id, name, value, callback){
    //console.log('name: ' + name + ', value: ' + value);
    var theQuery = "UPDATE tabla_cliente SET " + name + " = " + pool.escape(value) + " WHERE cliente_id = " + id;
    //TODO escape 'name' por seguridad, pero asegurarse de que no se pase con comillas o rompe al query
    //console.log(theQuery);
    pool.query(theQuery, function(err, result) {
      if (err) throw(err);
      callback(null, result)
    });
  }


}
module.exports = Cliente;
